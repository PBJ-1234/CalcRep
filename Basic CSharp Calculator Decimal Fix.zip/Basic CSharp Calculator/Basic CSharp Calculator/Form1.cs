﻿using Microsoft.SqlServer.Server;
using System;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Basic_CSharp_Calculator
{
    public partial class Form1 : Form
    {

        double result;
        string newL = Environment.NewLine;
        int dots = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') || (e.KeyChar == '(' || e.KeyChar == ')'))
            {
                int i = InputBox.Text.Length;
                if (e.KeyChar == '(')
                {
                    if(InputBox.Text[i - 1] >= '0' && InputBox.Text[i - 1] <= '9')
                        InputBox.Text += ('*');
                }

                InputBox.Text += e.KeyChar;
                
                if (e.KeyChar == ')')
                {
                    if (InputBox.Text[i - 1] >= '0' && InputBox.Text[i - 1] <= '9')
                        InputBox.Text += ('*');
                }
            }
            else if(e.KeyChar == '.')
            {
                dots++;
                int index = InputBox.Text.Length;
                if (dots >= 2)
                {
                    ErrBox.Text = "Invalid decimal input";
                    InputBox.Text = "";
                    dots = 0;
                }
                else if (InputBox.Text == "" || postValue(InputBox.Text[index-1]) > 0)
                {
                    InputBox.Text += "0.";
                }
                else
                {
                    InputBox.Text = InputBox.Text + ".";
                }
            }
            else
            {
                switch (e.KeyChar)
                {
                    case '+':
                    case '-':
                    case '/':
                    case '*':
                    case '^':
                        if( e.KeyChar == '-')
                        {
                            int i = InputBox.Text.Length;
                            if ((InputBox.Text.Length > 1) && (postValue(InputBox.Text[i - 1]) > 0 || (InputBox.Text[i - 1] == '(')))
                                InputBox.Text += "0";
                        }
                        int len = InputBox.Text.Length;
                        dots = 0;
                        if (len > 1 && InputBox.Text[len - 1] == '.')
                            InputBox.Text += 0;
                        InputBox.Text += e.KeyChar;
                        break;
                    case (char)Keys.Enter:
                        if (PastEntryBox.Text != "" && InputBox.Text != "")
                        {
                            dots = 0;
                            PostFixOp();
                        }
                        break;
                    // Backspace
                    case (char)Keys.Back:
                        len = InputBox.Text.Length;
                        if (len > 1 && InputBox.Text[len - 1] == '.')
                            dots = 0;
                        if (len > 0)
                        {
                            InputBox.Text = InputBox.Text.Substring(0, len - 1);
                        }
                        break;
                    // Clear Current Entry
                    case (char)Keys.Delete:
                        InputBox.Text = "";
                        dots = 0;
                        break;
                    default:
                        break;
                }

            }
        }
        private void LeftParen(object sender, MouseEventArgs e)
        {
            int i = InputBox.Text.Length;
            if (InputBox.Text[i - 1] >= '0' && InputBox.Text[i - 1] <= '9')
                InputBox.Text += ('*');
            InputBox.Text += '(';

        }
        private void RightParen(object sender, MouseEventArgs e)
        {
            int i = InputBox.Text.Length;
            if (InputBox.Text[i - 1] >= '0' && InputBox.Text[i - 1] <= '9')
                InputBox.Text += ('*');
            InputBox.Text += ')';
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void button0_MouseClick(object sender, MouseEventArgs e)
        {
            InputBox.Text += '0';
        }
        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            InputBox.Text += '1';
        }
        private void button2_MouseClick(object sender, MouseEventArgs e)
        {
            InputBox.Text += '2';
        }
        private void button3_MouseClick(object sender, MouseEventArgs e)
        {
            InputBox.Text += '3';
        }
        private void button4_MouseClick(object sender, MouseEventArgs e)
        {
            InputBox.Text += '4';
        }
        private void button5_MouseClick(object sender, MouseEventArgs e)
        {
            InputBox.Text += '5';
        }
        private void button6_MouseClick(object sender, MouseEventArgs e)
        {
            InputBox.Text += '6';
        }
        private void button7_MouseClick(object sender, MouseEventArgs e)
        {
            InputBox.Text += '7';
        }
        private void button8_MouseClick(object sender, MouseEventArgs e)
        {
            InputBox.Text += '8';
        }
        private void button9_MouseClick(object sender, MouseEventArgs e)
        {
            InputBox.Text += '9';
        }
        // Sqrt and x^2 just alter the previous result
        // Sqrt
        private void Sqrt(object sender, MouseEventArgs e)
        {
            ErrBox.Text = "";
            double num;
            if ((double.TryParse(PastEntryBox.Text, out num)) == true && num >= 0)
            {
                result = Math.Sqrt(num);
                PastEntryBox.Text = result.ToString();
                HistBox.Text += String.Format("{0} {1} {2} = {3} {4}", num, '^', "1/2", result, newL);
            }
            else
            {
                ErrBox.Text = "Invalid input";
            }
            dots = 0;
        }
        // x^2
        private void SquareNum(object sender, MouseEventArgs e)
        {
            ErrBox.Text = "";
            double num;
            if ((double.TryParse(PastEntryBox.Text, out num)) == true)
            {
                result = Math.Pow(num, 2);
                PastEntryBox.Text = result.ToString();
                HistBox.Text += String.Format("{0} {1} {2} = {3} {4}", num, '^', '2', result, newL);
            }
            else
            {
                ErrBox.Text = " Invalid input ";
            }
            dots = 0;
        }
        // x^y
        private void setPow(object sender, MouseEventArgs e)
        {
            operationFunc('^');
        }
        // Divide
        private void DiviBtn(object sender, MouseEventArgs e)
        {
            operationFunc('/');
        }
        // Multiply
        private void MutBtn(object sender, MouseEventArgs e)
        {
            operationFunc('*');
        }
        // Subtract
        private void SubtBtn(object sender, MouseEventArgs e)
        {
            int i = InputBox.Text.Length;
            if ((InputBox.Text.Length > 1) && (postValue(InputBox.Text[i - 1]) > 0 || (InputBox.Text[i - 1] == '(')))
            {
                InputBox.Text += "0";
            }
            operationFunc('-');
        }
        // Add
        private void AdBtn(object sender, MouseEventArgs e)
        {

            operationFunc('+');
        }        
        // 1/x inverse
        private void InverBtn(object sender, MouseEventArgs e)
        {
            InputBox.Text = "1/(" + InputBox.Text + ")";
        }
        // Change sign of result
        private void SignBtn(object sender, MouseEventArgs e)
        {
            double len, num;
            len = PastEntryBox.Text.Length;
            if (len > 0)
            {
                double.TryParse(PastEntryBox.Text, out num);
                num = num * -1;
                PastEntryBox.Text = num.ToString();
                HistBox.Text += String.Format("{0} {1} {2} = {3} {4}", num, '*', "-1", PastEntryBox.Text, newL);
            }
        }
        // Decimal
        private void DeciBtn(object sender, MouseEventArgs e)
        {
            dots++;
            int charIndex = InputBox.Text.Length;
            if (dots >= 2)
            {
                ErrBox.Text = "Invalid decimal input";
                InputBox.Text = "";
                dots = 0;
            }
            if (InputBox.Text == "" || postValue(InputBox.Text[charIndex-1]) >= 0)
            {
                InputBox.Text += "0.";
            }
            else
            {
                InputBox.Text = InputBox.Text + ".";
            }
        }
        // Clear last info entered
        private void clrLinBtn(object sender, MouseEventArgs e)
        {
            InputBox.Text = "";
            PastEntryBox.Text = "";
            dots = 0;
        }
        // Clear entire entry
        private void ClrBtn(object sender, MouseEventArgs e)
        {
            InputBox.Text = "";
            PastEntryBox.Text = "";
            ErrBox.Text = "";
            HistBox.Text = "";
            dots = 0;
        }
        // Delete last character
        private void DeleBtn(object sender, MouseEventArgs e)
        {
            int len = InputBox.Text.Length;
            if (len > 1 && InputBox.Text[len-1] == '.')
                dots = 0;
            if (len > 0)
                InputBox.Text = InputBox.Text.Substring(0, len - 1);
        }
        // Equals
        private void EqualBtn(object sender, MouseEventArgs e)
        {
            PostFixOp();
            dots = 0;
        }
        
        // Operator function
        private void operationFunc(char op)
        {
            int len = InputBox.Text.Length;
            if (len > 1 && InputBox.Text[len - 1] == '.')
                InputBox.Text += '0';
            InputBox.Text += op;
            dots = 0;
        }

         // Function to make find operator val
        private int postValue(char op)
        {
            switch (op)
            {
                case '^':
                    return 3;
                case '*':
                case '/':
                    return 2;
                case '+':
                case '-':
                    return 1;
            }
            return 0;
        }

        private void PostFixButton(object sender, MouseEventArgs e)
        {
            PostFixOp();
        }
        private void PostFixOp()
        { 
            int i, space = 0;
            int parens = 0;
            char c, b;
            Stack values = new Stack();
            Stack<double> final = new Stack<double>();
            string resultExp = "";

            // Fill equation into postfix form
            for (i = 0; i < InputBox.Text.Length; i++)
            {
                c = InputBox.Text[i];
                bool status = (c >= '0' && c <= '9');
                Console.Write("Status: " + status + " ");
                if((c >= '0' && c <= '9') || (c == '-' && i == 0) || c == '.')
                {
                    Console.Write("Val: " + c + "\n");
                    if (resultExp.Length > 1)
                    {
                        b = InputBox.Text[i - 1];
                        // Adds space to seperate nums and operators
                        if ((b >= '0' && b <= '9') || (b == '-' && i == 1) || b == '.')
                            resultExp = resultExp.Substring(0, resultExp.Length - 1);
                    }
                    
                    resultExp += c + " ";
                }
                else if(c == '(')
                {

                    values.Push(c);
                    parens = 1;
                }
                else if (c == ')')
                {
                    while(values.Count > 0 && (char)values.Peek() != '(' )
                    {
                        resultExp += values.Pop();
                    }
                    if(values.Count > 0 && (char)values.Peek() != '(')
                    {
                        ErrBox.Text= "Invalid characters input";
                    }
                    else
                    {
                        values.Pop();
                    }
                    parens = 0;
                }
                else
                {
                    Console.Write(" Operator Reached ");
                    if(values.Count == 0 || parens == 1)
                    {
                        values.Push(c);
                    }
                    else
                    {
                        while ( ( values.Count > 0 && postValue(c) <= postValue( (char)values.Peek() ) ) )
                        {
                            resultExp += values.Pop();
                        }
                        values.Push(c);
                    }
                }
                Console.WriteLine("Current: " + resultExp);
            }
            while(values.Count > 0)
            {
                resultExp += values.Pop();
            }
            Console.WriteLine("Reached Equal Function");
            Console.WriteLine(resultExp);
            // Process Equation
            {
                final.Clear();
                space = 0;
                int dec = 0, neg = 0;
                string expr = resultExp;
                double num1, num2, res;
                for (i = 0; i < expr.Length; i++)
                {
                    c = expr[i];
                    if ((c >= '0' && c <= '9') || (c == '-' && i == 0) || c == '.')
                    {
                        if (c == '-' && i == 0)
                        {
                            final.Push(char.GetNumericValue(expr[i + 1]) * -1);
                            space = 1;
                            i++;
                        }
                        else if (space == 1)
                        {
                            double x = final.Pop();
                            Console.WriteLine("Cont Num: " + x + " Add: " + c);
                            if (c == '.')
                                dec++;
                            else
                            {
                                if(x < 0)
                                {
                                    x = x * -1;
                                    neg = 1;
                                }

                                if (dec == 0)
                                    x = (x * 10) + char.GetNumericValue(c);
                                else
                                {
                                    int y = 10;
                                    if(expr[i - 1] == 0)
                                        dec++;
                                    for (int k = 1; k < dec; k++)
                                        y = y * 10;
                                    x += 0 + (char.GetNumericValue(c) / y);
                                    Console.WriteLine("Decimal: " + x + " " + char.GetNumericValue(c) + " " + char.GetNumericValue(c)/y);
                                    dec++;
                                }

                                if (neg == 1)
                                {
                                     x = x * - 1;
                                     neg = 0;
                                }
                                   
                            }
                            final.Push(x);
                            Console.WriteLine(final.Peek() + " ");
                        }
                        else
                        {
                            double x = char.GetNumericValue(c);
                            Console.WriteLine("New Num: " + x + " ");
                            final.Push(x);
                            space = 1;
                            dec = 0;
                        }
                        
                    }
                    else if(postValue(c) > 0)
                    {
                        Console.WriteLine("Operator Reached");
                        space = 0;
                        dec = 0;
                        num2 = final.Pop();
                        Console.WriteLine(num2);
                        num1 = final.Pop();
                        switch (c)
                        {
                            case '+':
                                res = num1 + num2;
                                break;
                            case '-':
                                res = num1 - num2;
                                break;
                            case '/':
                                res = num1 / num2;
                                break;
                            case '*':
                                res = num1 * num2;
                                break;
                            case '^':
                                res = Math.Pow(num1, num2);
                                break;
                            default:
                                ErrBox.Text = "Invalid Char found";
                                InputBox.Text = "";
                                return;
                        }
                     
                        final.Push(res);
                        Console.Write(final.Peek() + " ");
                        Console.WriteLine(res);
                    }
                    else if ( c == ' ')
                    {
                        space = 0;
                    }
                }
                string finishText = final.Pop().ToString();
                PastEntryBox.Text = finishText;
                HistBox.Text += InputBox.Text + " = " + finishText + newL;
                InputBox.Text = "";
            }
        }


    }

}
